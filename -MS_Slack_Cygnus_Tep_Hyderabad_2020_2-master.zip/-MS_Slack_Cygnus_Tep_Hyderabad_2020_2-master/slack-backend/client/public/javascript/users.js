const showMembersContainer = document.getElementById('showMembers__container');

nrOfMembers.addEventListener('click', () => {
    showMembersContainer.style.display = "block";
    overlay.style.display = "block";
})
