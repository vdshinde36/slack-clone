| Feature | Assigned to | Deadline | Completed On |
|---------|-------------|----------|--------------|
|    Backend     |  Vaibhav           | 25/08/2020         |     25/08/2020         |
|    Frontend( Authentication, Panels and Electron integration)     |   Ujjwal         |   22/08/2020       |   22/08/2020           |
|    Frontend(messages,messageform ,channels,private messages etc.)     |    Krishna         |  24/08/2020        |   24/08/2020           |
