import React from "react";
//class component for metapanel
class MetaPanel extends React.Component {
  render() {
    return <div></div>;
  }
}

export default MetaPanel;
